﻿Imports System
Imports System.Data
Imports System.IO
Imports System.Xml
Imports System.Data.SqlClient
Imports System.Collections.Generic
Imports Microsoft.SqlServer.Management.Smo
Imports Microsoft.SqlServer.Management.Common
Imports Microsoft.Office.Interop
Imports System.Data.OleDb
Imports Microsoft.WindowsAPICodePack.Taskbar
Imports System.Text.RegularExpressions
Module BasicFunc
    'MAIN SQL CUSTOMER SCRIPTS
    Public Function Retrive_SQL_Scripts(ByVal SQL_Script_Path As String) As Integer
        Dim NmOfFiles As Integer
        Dim TblNm As String
        Try
            If Directory.GetFiles(SQL_Script_Path).Length = 0 Then
                UpdateLog(True, "ERROR...No Files Found in location-" & SQL_Script_Path)
                Return 0
                Exit Function
            Else
                Dim di As New IO.DirectoryInfo(SQL_Script_Path & "\")
                Dim diar1 As IO.FileInfo() = di.GetFiles("*.sql")
                Dim dra As IO.FileInfo
                MnFrm.cmbx_tblNm_insrt.Items.Clear()
                For Each dra In diar1
                    MnFrm.Lst_SQLScrpt_Nm.Items.Add(dra)
                    If CustPath = "" Then CustPath = Replace(dra.FullName, dra.Name, "") 'filling cust path
                    TblNm = dra.Name
                    TblNm = Regex.Replace(TblNm, ".SQL", "", RegexOptions.IgnoreCase)
                    TblNm = Right(TblNm, Len(TblNm) - InStrRev(TblNm, "."))
                    MnFrm.cmbx_tblNm_insrt.Items.Add(TblNm)
                    ' UpdateLog(True, "FEEDING..." & dra.FullName)
                    NmOfFiles = NmOfFiles + 1
                Next
                '  MnFrm.cmbx_tblNm_insrt.Items.Add("PSOnyxP1Products")
            End If
            UpdateLog(True, "Loaded " & NmOfFiles & " File(s) from-" & SQL_Script_Path)
        Catch ex As Exception
            UpdateLog(True, "ERROR..." & Err.Description)
        End Try

        Return NmOfFiles

    End Function
    
    Public Function Create_ScrptTbl(CreateTable As Boolean, OutputPath As String) As Integer
        Dim sql As String
        Dim rowsAffected As Integer = 0
        Dim NmbrOfScrpt As Integer
        Dim OldCustNm As String
        Dim NewCustNm As String
        Dim FlPath As String
        Dim FlNm As String
        Dim Script As String
        Dim NewFle
        Dim SrcTblNm As String
        Dim NewTblNm As String
        Dim connectionString As String
        Dim Conn As SqlConnection
        Dim cmd As SqlCommand
        Dim OutputFile As String
        Dim FileExists As Boolean
        Dim UpdtMsg As String
        Dim TblExists As Integer
        '  If Not Conn Is Nothing Then Conn.Close()

        If CreateTable = True Then
            connectionString = "Data Source=" & ServerNm & ";Initial Catalog=" & DBNm & ";Integrated Security=SSPI"
            Conn = New SqlConnection(connectionString)
            cmd = New SqlCommand()
            cmd.Connection = Conn
            Conn.Open()
        End If

        MnFrm.pb_mainProcess.Maximum = MnFrm.Lst_SQLScrpt_Nm.SelectedItems.Count()
        For Each itm In MnFrm.Lst_SQLScrpt_Nm.SelectedItems
            FlNm = itm.name
            Try
                If (Not Directory.Exists(OutputPath)) Then
                    Directory.CreateDirectory(OutputPath)
                End If
                OldCustNm = Trim(FlNm)
                OldCustNm = Right(OldCustNm, Len(OldCustNm) - InStrRev(OldCustNm, "_"))
                OldCustNm = "_" & Regex.Replace(OldCustNm, ".SQL", "", RegexOptions.IgnoreCase)
                NewCustNm = "_" & Trim(MnFrm.cmbx_newCustNm.Text)
                SrcTblNm = Regex.Replace(FlNm, ".SQL", "", RegexOptions.IgnoreCase)
                SrcTblNm = Right(SrcTblNm, Len(SrcTblNm) - InStrRev(SrcTblNm, "."))

                NewTblNm = Regex.Replace(FlNm, OldCustNm, NewCustNm, RegexOptions.IgnoreCase)
                NewTblNm = Regex.Replace(NewTblNm, ".SQL", "", RegexOptions.IgnoreCase)
                NewTblNm = Right(NewTblNm, Len(NewTblNm) - InStrRev(NewTblNm, "."))
                FlPath = CustPathCustName & FlNm

                If CreateTable = True Then
                    'CREATING BLANK TABLE
                    NewTblNm = DBNm & ".dbo." & NewTblNm
                    SrcTblNm = DBNm & ".dbo." & SrcTblNm
                    sql = "SELECT COUNT(*) FROM sys.objects " & _
                           "WHERE object_id = OBJECT_ID('" & NewTblNm & "',N'U') "
                    cmd.CommandText = sql
                    TblExists = cmd.ExecuteScalar()
                    If TblExists = 0 Then
                        UpdtMsg = "CREATED TABLE"
                    Else
                        UpdtMsg = "REPLACED TABLE "
                    End If
                    sql = "IF OBJECT_ID ('" & NewTblNm & "',N'U') IS NOT NULL DROP TABLE " & NewTblNm & ""
                    sql = sql & " SELECT * INTO " & NewTblNm & " FROM " & SrcTblNm & " WHERE 1=0"
                    UpdateLog(True, "CHECKING..." & Regex.Replace(NewTblNm, DBNm & ".dbo.", "", RegexOptions.IgnoreCase))
                    cmd.CommandText = sql
                    cmd.ExecuteNonQuery()
                    UpdateLog(True, UpdtMsg & "..." & LCase(NewTblNm))
                    Script = "SELECT * FROM " & NewTblNm
                Else
                    Script = File.ReadAllText(FlPath)
                    Script = Regex.Replace(Script, OldCustNm, NewCustNm, RegexOptions.IgnoreCase)
                    Script = Regex.Replace(Script, "'" & Replace(OldCustNm, "_", "") & "'", "'" & Replace(NewCustNm, "_", "") & "'", RegexOptions.IgnoreCase)
                End If

                OutputFile = OutputPath & "\" & Regex.Replace(FlNm, OldCustNm, NewCustNm, RegexOptions.IgnoreCase)
                FileExists = File.Exists(OutputFile)

                NewFle = File.CreateText(OutputFile)
                NewFle.WriteLine(Script)
                NewFle.Close()

                If FileExists = True And CreateTable = True Then
                    UpdateLog(True, "REPLACED SCRIPT..." & OutputFile)
                ElseIf FileExists = True And CreateTable = False Then
                    UpdateLog(True, "REPLACED SCRIPT..." & OutputFile)
                ElseIf CreateTable = True Then
                    UpdateLog(True, "CREATED SCRIPT(BLANK)..." & OutputFile)
                Else
                    UpdateLog(True, "CREATED SCRIPT..." & OutputFile)
                End If
            Catch ex As Exception
                UpdateLog(True, "ERROR..." & Err.Description)
            End Try
            NmbrOfScrpt = NmbrOfScrpt + 1
            MnFrm.pb_mainProcess.Value = NmbrOfScrpt
            Application.DoEvents()
        Next

        If CreateTable = True Then
            Conn.Close()
            cmd.Dispose()
        End If

        Return NmbrOfScrpt
    End Function

    'ERROR CHECKING SQL SCRIPTS
    Public Function Retrive_ErrorChk_Scripts(ByVal ErrChk_Script_Path As String) As Integer
        Dim FilesFound As Boolean = False
        Dim FlNm As String
        Dim FlNm2 As String
        Dim NmOfFiles As Integer
        Dim str(3) As String
        Dim itm As ListViewItem

        If Directory.Exists(ErrChk_Script_Path) = False Then
            Dim ofd As New FolderBrowserDialog
            ofd.Description = "Select ErrorCheck Folder"
            ' ofd.RootFolder = MnFrm.txt_BasePath.Text
            ofd.SelectedPath = RootPath
            If ofd.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                ErrChkScrptPath = (ofd.SelectedPath) & "\"
            Else
                Return 0
                UpdateLog(True, "ERROR...No Folders selected , Operation Cancelled by user")
                Exit Function
            End If
        Else
            ErrChkScrptPath = ErrChk_Script_Path & "\"
        End If

        If Directory.GetFiles(ErrChkScrptPath).Length = 0 Then
            UpdateLog(True, "ERROR...No Error Chk Scripts Found in folder " & ErrChk_Script_Path)
            Return 0
            Exit Function
        End If
        MnFrm.LstV_ErrChk.Items.Clear()
        MnFrm.LstV_ErrChk.Columns.Clear()
        MnFrm.LstV_ErrChk.Columns.Add("Script Name", 480, HorizontalAlignment.Left)
        MnFrm.LstV_ErrChk.Columns.Add("Err. Rcd Cnt", 70, HorizontalAlignment.Left)
        MnFrm.LstV_ErrChk.Columns.Add("Status", 120, HorizontalAlignment.Left)
        MnFrm.LstV_ErrChk.Columns.Add("Source Table Name", 250, HorizontalAlignment.Left)

        Dim di As New IO.DirectoryInfo(ErrChkScrptPath)
        Dim diar1 As IO.FileInfo() = di.GetFiles("*.sql")

        For Each dra In diar1
            If InStr(dra.Name, "_") = 0 Then
                UpdateLog(True, "ERROR...(Underscore) _ missing in " & ErrChkScrptPath & dra.Name & "... ")
                GoTo nextScript
            End If

            FlNm = Left(dra.Name, InStr(dra.Name, "_") - 1)
            FlNm = Right(FlNm, Len(FlNm) - InStrRev(FlNm, "."))

            'if get all scripts box is checked
            If MnFrm.ckbx_IncludeAllErrorChkScrpts.Checked = True Then
                str(0) = dra.Name
                FlNm2 = Regex.Replace(FlNm2, ".SQL", "", RegexOptions.IgnoreCase)
                FlNm2 = Right(FlNm2, Len(FlNm2) - InStrRev(FlNm2, "."))
                str(3) = FlNm2
                itm = New ListViewItem(str)
                MnFrm.LstV_ErrChk.Items.Add(itm)
                NmOfFiles = NmOfFiles + 1
            Else
                For Each selItm In MnFrm.Lst_SQLScrpt_Nm.SelectedItems
                    FlNm2 = selItm.name
                    If InStr(UCase(FlNm2), UCase(FlNm)) > 0 Then
                        str(0) = dra.Name
                        FlNm2 = Regex.Replace(FlNm2, ".SQL", "", RegexOptions.IgnoreCase)
                        FlNm2 = Right(FlNm2, Len(FlNm2) - InStrRev(FlNm2, "."))
                        str(3) = FlNm2
                        itm = New ListViewItem(str)
                        MnFrm.LstV_ErrChk.Items.Add(itm)
                        NmOfFiles = NmOfFiles + 1
                        Exit For
                    End If
                Next selItm
            End If
nextScript:
        Next dra

        Return NmOfFiles

    End Function
    Public Function Run_ErrorChk_Scripts() As Integer
        Dim NmbrOfScrpt As Integer
        Dim cnt As Integer
        Dim watch As New Stopwatch()
        Dim FlPath As String
        Dim FlNm As String
        Dim cmd As New SqlClient.SqlCommand
        Dim reader As SqlDataReader
        Dim Script

        Dim sqlConnectionString As String = "Data Source=" & ServerNm & ";Initial Catalog=" & DBNm & ";Integrated Security=SSPI"
        cmd.Connection = New SqlClient.SqlConnection(sqlConnectionString)
        cmd.Connection.Open()
        UpdateProgressBar(False, MnFrm.LstV_ErrChk.Items.Count())

        For Each itm As ListViewItem In MnFrm.LstV_ErrChk.Items
            itm.UseItemStyleForSubItems = False
            FlNm = itm.SubItems.Item(0).Text
            FlPath = ErrChkScrptPath & FlNm
            Script = System.IO.File.ReadAllText(FlPath)
            Script = Regex.Replace(Script, "%CustAlias%", MnFrm.Cmbx_CustNm.Text, RegexOptions.IgnoreCase)
            If InStr(UCase(Script), vbCr & vbLf & "GO" & vbCr & vbLf) > 0 Then
                UpdateLog(True, "ERROR...Please remove ""GO"" from the Script """ & LCase(FlPath) & """")
                GoTo SkipCurrScrpt
            End If
            watch.Start()
            UpdateLog(True, "RUNNING... " & LCase(FlPath))
            Try
                cmd.CommandText = Script
                reader = cmd.ExecuteReader()
                If reader.HasRows Then
                    cnt = 0
                    While reader.Read
                        cnt = cnt + 1
                    End While
                    itm.SubItems.Item(1).Text = cnt
                    itm.SubItems.Item(2).Text = "FAIL"
                    itm.SubItems.Item(2).BackColor = Color.Red
                Else
                    itm.SubItems.Item(1).Text = 0
                    itm.SubItems.Item(2).Text = "PASS"
                    itm.SubItems.Item(2).BackColor = Color.LimeGreen
                End If
                reader.Close()
                watch.Stop()
                If watch.Elapsed.TotalSeconds.ToString > 120 Then
                    UpdateLog(False, "...DONE- " & watch.Elapsed.TotalMinutes.ToString("0.00") & "min")
                Else
                    UpdateLog(False, "...DONE- " & watch.Elapsed.TotalSeconds.ToString("0.00") & "sec   ")
                End If
            Catch ex As Exception
                itm.SubItems.Item(2).Text = "ERROR"
                itm.SubItems.Item(2).BackColor = Color.Red
                UpdateLog(False, "...ERROR..." & Err.Description & " " & Script)
                GoTo SkipCurrScrpt
            End Try
SkipCurrScrpt:
            NmbrOfScrpt = NmbrOfScrpt + 1
            UpdateProgressBar(NmbrOfScrpt, False)
            Application.DoEvents()
        Next
        cmd.Connection.Close()
        Return NmbrOfScrpt
    End Function
    Public Function Load_ErrorChk_Scripts2DataGrid(ScrptPath As String) As Integer
        Dim watch As New Stopwatch()
        Dim Script
        Dim sqlConnectionString As String = "Data Source=" & ServerNm & ";Initial Catalog=" & DBNm & ";Integrated Security=SSPI"
        Dim connection As SqlConnection = New SqlConnection(sqlConnectionString)
        Dim cmd As SqlCommand = New SqlCommand()
        cmd.Connection = connection
        connection.Open()
        ScrptPath = ErrChkScrptPath & ScrptPath
        Script = System.IO.File.ReadAllText(ScrptPath)
        Script = Regex.Replace(Script, "%CustAlias%", MnFrm.Cmbx_CustNm.Text, RegexOptions.IgnoreCase)

        If InStr(UCase(Script), "SELECT *") = 0 Then
            UpdateLog(True, "ERROR...There must be exact ""SELECT * "" in """ & ScrptPath & """")
            GoTo SkipScrpt
        End If
        If InStr(UCase(Script), vbCr & vbLf & "GO" & vbCr & vbLf) > 0 Then
            UpdateLog(True, "ERROR...Please remove ""GO"" from the Script """ & ScrptPath & """")
            GoTo SkipScrpt
        End If
        DeleteRcdsSQLQry = Replace(UCase(Script), "SELECT *", "DELETE")
        watch.Start()
        UpdateLog(True, "Running ... " & Right(ScrptPath, Len(ScrptPath) - InStrRev(ScrptPath, "/")))

        MnFrm.pb_mainProcess.Maximum = 5
        MnFrm.pb_mainProcess.Value = 2
        Try
            cmd.CommandText = Script
            Dim reader As SqlDataReader = cmd.ExecuteReader()
            Dim dt As New DataTable
            dt.Load(reader)
            MnFrm.dgv_MsmtDta.DataSource = dt
            MnFrm.dgv_MsmtDta.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells
            reader.Close()
        Catch ex As Exception
            UpdateLog(True, "ERROR... " & Err.Description)
        End Try
        connection.Close()
        cmd.Dispose()
        UpdateLog(False, "...DONE- " & watch.Elapsed.TotalMinutes.ToString("0.00") & "min")
SkipScrpt:
        MnFrm.pb_mainProcess.Value = 5
        Return MnFrm.dgv_MsmtDta.RowCount - 1

    End Function
    'DATAGRID ------ update values
    Public Function Update_DtaVw_Rcds() As Integer
        Dim connetionString As String
        Dim ColNm
        Dim ColVal
        Dim ColValFnl
        Dim sql As String
        Dim i As Integer
        Dim ColFilled As Boolean
        Dim rowsAffected As Integer = 0
        Dim rowsAffected2 As Integer = 0

        connetionString = "Data Source=" & ServerNm & ";Initial Catalog=" & DBNm & ";Integrated Security=SSPI"
        Dim connectionString As String = "Data Source=" & ServerNm & ";Initial Catalog=" & DBNm & ";Integrated Security=SSPI"
        Dim connection As SqlConnection = New SqlConnection(connectionString)
        Dim cmd As SqlCommand = New SqlCommand()
        cmd.Connection = connection
        connection.Open()

        MnFrm.pb_mainProcess.Maximum = 5
        MnFrm.pb_mainProcess.Value = 2
        ' Execute as a transaction, roll back if it fails
        Dim transaction As SqlTransaction = connection.BeginTransaction()
        cmd.Transaction = transaction
        Try
            If MnFrm.ckbx_InsertRcds.Checked = False Then
                'DELETING RECORDS
                sql = DeleteRcdsSQLQry
                UpdateLog(True, "RUNNING..." & LCase(sql))
                cmd.CommandText = sql
                rowsAffected = cmd.ExecuteNonQuery()
            End If
            'ADDING RECORDS FROM DATAGRIDVIEW
            ColFilled = False
            ColNm = ""
            ColValFnl = ""
            For Each row As DataGridViewRow In MnFrm.dgv_MsmtDta.Rows
                i = 0
                If MnFrm.dgv_MsmtDta.RowCount = 1 Then GoTo CommitTran
                If Not row.IsNewRow Then
                    ColVal = ""
                    For Each col As DataGridViewColumn In MnFrm.dgv_MsmtDta.Columns
                        If ColFilled = False Then ColNm = ColNm & "[" & col.Name & "], "
                        'ColVal = ColVal & "'" & IIf(IsDBNull(row.Cells(i).Value) = True, "NULL", row.Cells(i).Value.ToString) & "', "
                        ColVal = ColVal & "'" & Replace(Replace(row.Cells(i).Value.ToString, "''", "'"), "'", "''") & "', "  ' removing '' and adding '
                        i = i + 1
                    Next
                    ColFilled = True
                    ColVal = Left(ColVal, Len(ColVal) - 2)   ' removing comma and space
                    ColValFnl = ColValFnl & " SELECT " & ColVal & vbNewLine & " UNION ALL "
                End If
            Next
            ColValFnl = Left(ColValFnl, Len(ColValFnl) - 11)
            'ColValFnl = Replace(ColValFnl, "'NULL'", "NULL") 'changing 'null' values to NULL
            ColNm = Left(ColNm, Len(ColNm) - 2)
            sql = "INSERT INTO " & DBNm & ".dbo." & MnFrm.cmbx_tblNm_insrt.Text & " (" & ColNm & ") " & ColValFnl
            UpdateLog(True, "RUNNING..." & LCase(sql))
            cmd.CommandText = sql
            rowsAffected2 = cmd.ExecuteNonQuery()
        Catch ex As Exception
            UpdateLog(False, "ERROR..." & Err.Description & "..ROLLED BACK")
            transaction.Rollback()
            connection.Close()
            Exit Function
        End Try
CommitTran:
        UpdateLog(True, "Deleted " & rowsAffected & " record(s)")
        UpdateLog(False, " /Added " & rowsAffected2 & " records(s)")
        transaction.Commit()
        connection.Close()
        cmd.Dispose()
        MnFrm.pb_mainProcess.Value = 5
    End Function
    'DATAGRID ------  export grid to Excel 
    Function Export_Grid_2_Exl()
        If MnFrm.dgv_MsmtDta Is Nothing OrElse MnFrm.dgv_MsmtDta.RowCount <= 0 Then
            UpdateLog(True, "ERROR...No data to Export")
            Exit Function
        End If

        Dim xlApp As New Excel.Application
        Dim xlWorkBook As Excel.Workbook
        Dim xlFlNm
        Dim misValue As Object = System.Reflection.Missing.Value

        MnFrm.pb_mainProcess.Maximum = 5
        MnFrm.pb_mainProcess.Value = 2

        Try
            xlWorkBook = xlApp.Workbooks.Add '(misValue)
            xlApp.Visible = True
            Dim xlWorkSheet = xlWorkBook.ActiveSheet

            'Data transfer from grid to Excel. 
            With xlWorkSheet
                'Set Clipboard Copy Mode
                MnFrm.dgv_MsmtDta.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText
                MnFrm.dgv_MsmtDta.SelectAll()
                'Get the content from Grid for Clipboard
                Dim str As String = TryCast(MnFrm.dgv_MsmtDta.GetClipboardContent().GetData(DataFormats.UnicodeText), String)
                'Set the content to Clipboard
                Clipboard.SetText(str, TextDataFormat.UnicodeText)
                'Identifiy and select the range of cells in excel to paste the clipboard data.
                .Range("A1:" & ConvertToLetter(MnFrm.dgv_MsmtDta.ColumnCount) & MnFrm.dgv_MsmtDta.RowCount, misValue).Select()
                'Paste the clipboard data
                .Paste()
                Clipboard.Clear()

                .Rows("1:1").Interior.ColorIndex = 24
                .Columns.AutoFit()
                .Columns("A:A").delete()
                .range("A1").select()
                xlFlNm = RootPath & "Excel_Export\" & MnFrm.cmbx_tblNm_insrt.Text & "_" & Format(Now(), "mmddyy_hhmmss") & ".xlsx"
                .SaveAs(xlFlNm)
                UpdateLog(True, "EXPORTED..." & xlFlNm)
            End With
            releaseObject(xlWorkSheet)

        Catch ex As Exception
            UpdateLog(True, "ERROR..." & Err.Description)
        Finally
            releaseObject(xlWorkBook)
            releaseObject(xlApp)
        End Try
        MnFrm.pb_mainProcess.Value = 5
    End Function
    'DATAGRID ------ load excel to grid
    Public Sub Load_XL2Grid()
        Dim ofd As New OpenFileDialog
        Dim SheetNm As String
        ofd.Filter = "Excel Files|*.xlsx;"
        ofd.Title = "Select Excel File"
        ofd.InitialDirectory = RootPath & "Excel_Export"
        If ofd.ShowDialog <> System.Windows.Forms.DialogResult.OK Then
            UpdateLog(True, "CANCELLED...Cancelled by User")
            Exit Sub
        End If

        Dim connString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & ofd.FileName & ";Extended Properties=Excel 12.0;"

        Using conn As New OleDbConnection(connString)
            conn.Open()
            Dim dtSchema = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, New Object() {Nothing, Nothing, Nothing, "TABLE"})
            SheetNm = dtSchema.Rows(0).Field(Of String)("TABLE_NAME")
            conn.Close()
            conn.Dispose()
        End Using

        Dim MyConn As OleDbConnection
        MyConn = New OleDbConnection
        MyConn.ConnectionString = connString
        Dim da As OleDbDataAdapter

        MnFrm.pb_mainProcess.Maximum = 5
        MnFrm.pb_mainProcess.Value = 2

        Try
            da = New OleDbDataAdapter("SELECT * from [" & SheetNm & "]", MyConn) 'Change items to your database name
            Dim ds As New DataSet
            da.Fill(ds)
            MnFrm.dgv_MsmtDta.DataSource = ds.Tables(0)
            MnFrm.dgv_MsmtDta.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells
            UpdateLog(True, "Imported " & ofd.FileName)
        Catch ex As Exception
            UpdateLog(True, "ERROR... " & Err.Description)
        End Try
        MnFrm.pb_mainProcess.Value = 5
    End Sub
    'EXPORT TEMPLATE TO EXCEL
    Public Function Export2Exl() As Integer
        Dim NmbrOfFle As Integer
        Dim FlNm As String
        Dim ShtNm As String
        Dim strSQL, xlFlNm As String
        Dim rs As New ADODB.Recordset
        Dim cn As New ADODB.Connection
        cn.ConnectionString = ("Provider=sqloledb;Data Source=" & ServerNm & ";Initial Catalog=" & DBNm & ";Integrated Security=SSPI")
        cn.Open()

        Dim xlApp As New Excel.Application
        If xlApp Is Nothing Then
            UpdateLog(True, "ERROR...Excel not installed/ found")
            End
        End If

        Dim xlWB As Excel.Workbook = xlApp.Workbooks.Add  ' create a new workbook
        Dim xlWS As Excel.Worksheet = xlWB.Worksheets(1)
        'xlApp.Visible = True
        MnFrm.pb_mainProcess.Maximum = MnFrm.Lst_SQLScrpt_Nm.SelectedItems.Count()
        Try
            For Each itm In MnFrm.Lst_SQLScrpt_Nm.SelectedItems
                FlNm = itm.name
                '   If UCase(FlNm) Like "*TEMPLATE*" Then
                UpdateLog(True, "Reading ... " & FlNm)
                FlNm = Regex.Replace(FlNm, ".sql", "", RegexOptions.IgnoreCase)
                FlNm = Right(FlNm, Len(FlNm) - InStrRev(FlNm, "."))
                strSQL = "SELECT * FROM " & DBNm & ".dbo." & FlNm & " ;"

                rs = cn.Execute(strSQL)
                xlWS = xlWB.Worksheets.Add(After:=xlWB.Sheets(xlWB.Sheets.Count))
                ShtNm = Regex.Replace(FlNm, "_TEMPLATE", "", RegexOptions.IgnoreCase)
                If Len(ShtNm) > 30 Then ShtNm = Left(ShtNm, 30)
                xlWS.Name = ShtNm
                If Len(xlFlNm) < 108 Then xlFlNm = xlFlNm & xlWS.Name & "_"

                With xlWS
                    .Rows("1:1").Interior.ColorIndex = 24
                    For fldcol = 0 To rs.Fields.Count - 1
                        .Cells(1, fldcol + 1).Value = rs.Fields(fldcol).Name
                    Next fldcol
                    .Cells(2, 1).CopyFromRecordset(rs)
                    .Columns.AutoFit()
                End With
                UpdateLog(False, "...DONE")
                MnFrm.pb_mainProcess.Value = NmbrOfFle
                Application.DoEvents()
                NmbrOfFle = NmbrOfFle + 1
                '  End If
            Next itm
            If xlApp.Sheets.Count > 3 Then
                xlWB.Sheets("Sheet1").delete()
                xlWB.Sheets("Sheet2").delete()
                xlWB.Sheets("Sheet3").delete()
            End If

            xlWS = CType(xlApp.Worksheets(1), Excel.Worksheet)
            xlWS.Activate()
            xlFlNm = RootPath & "Excel_Export\" & xlFlNm & Format(Now(), "mmddyy_hhmmss") & ".xlsx"
            xlWS.SaveAs(xlFlNm)
            xlWB.Sheets("Sheet1").delete()
            xlApp.Visible = True

            '  xlWB.Close()

            System.Runtime.InteropServices.Marshal.ReleaseComObject(xlApp)
            xlApp = Nothing
            xlWB = Nothing
            xlWS = Nothing

            rs.Close()
            rs = Nothing
            cn.Close()
            cn = Nothing
            UpdateLog(True, "Exported... " & xlFlNm)

        Catch ex As Exception
            xlWB.Close(False)
            UpdateLog(True, "ERROR..." & Err.Description)
        End Try

        Return NmbrOfFle
    End Function
    Public Sub UpdateProgressBar(ByVal Val, ByVal MaxVal)
        If MaxVal <> False Then MnFrm.pb_mainProcess.Maximum = MaxVal
        If Val <> False And Val <= MnFrm.pb_mainProcess.Maximum Then MnFrm.pb_mainProcess.Value = Val
        MnFrm.pb_mainProcess.Refresh()
        TaskbarManager.Instance.SetProgressValue(MnFrm.pb_mainProcess.Value, MnFrm.pb_mainProcess.Maximum)
        Application.DoEvents()

    End Sub
    Public Sub UpdateLog(ByVal NewLine As Boolean, ByVal LogMsg As String)
        If LogMsg = "START>>" Then
            MnFrm.Txt_Log.AppendText(vbNewLine)
            MnFrm.Txt_Log.AppendText("----------------------------------------------------------------------------------------------------------------------------------")
            MnFrm.Txt_Log.AppendText(vbNewLine & "START>>" & " " & Format(Now(), "hh:mm:ss tt"))
            MnFrm.Txt_Log.ForeColor = Color.FromArgb(182, 182, 0)
            MnFrm.lbl_mainStatsBar.Text = "Processing..."
        ElseIf LogMsg = "<<END" Then
            MnFrm.Txt_Log.AppendText(vbNewLine & "<<END" & " " & Format(Now(), "hh:mm:ss tt"))
            MnFrm.lbl_mainStatsBar.Text = "Ready"
        Else
            If NewLine = True Then
                MnFrm.Txt_Log.AppendText(vbNewLine & LogMsg)
            Else
                MnFrm.Txt_Log.AppendText(LogMsg)
            End If
            If InStr(LogMsg, "DONE") = 0 Then MnFrm.lbl_mainStatsBar.Text = LogMsg
        End If
        MnFrm.lbl_mainStatsBar.Refresh()

        MnFrm.Txt_Log.SelectionStart = MnFrm.Txt_Log.Text.Length
        MnFrm.Txt_Log.Refresh()
        MnFrm.Txt_Log.ScrollToCaret()

        Dim LastScript() As String = Split(MnFrm.Txt_Log.Text, "START>>")
        If InStr((LastScript(UBound(LastScript))), "ERROR...") > 0 Then
            MnFrm.Txt_Log.ForeColor = Color.FromArgb(196, 0, 0)
        ElseIf InStr((LastScript(UBound(LastScript))), "CANCELLED by User") > 0 Then
            MnFrm.Txt_Log.ForeColor = Color.FromArgb(196, 0, 0)
        ElseIf LogMsg = "<<END" And MnFrm.Txt_Log.ForeColor <> Color.FromArgb(196, 0, 0) Then
            MnFrm.Txt_Log.ForeColor = Color.FromArgb(1, 222, 0)
        End If

        'Dim length As Integer = RichTextBox.TextLength
        '' at end of text
        'RichTextBox.AppendText(mystring)
        'RichTextBox.SelectionStart = length
        'RichTextBox.SelectionLength = mystring.Length
        'RichTextBox.SelectionColor = Color.Red

    End Sub
    Public Function SelectionCheck(ByVal OnlyTemplateScripts As Boolean) As Boolean
        Dim IsSelected As Boolean

        For Each Itm In MnFrm.Lst_SQLScrpt_Nm.SelectedItems
            If UCase(Itm.name) Like "*TEMPLATE*" And OnlyTemplateScripts = True Then IsSelected = True
            If OnlyTemplateScripts = False Then IsSelected = True
        Next
        If IsSelected = False And OnlyTemplateScripts = True Then
            MsgBox("Select atleast one ""TEMPLATE"" Script from the list", MsgBoxStyle.Critical, Title:="Selection Required")
            Return False
        ElseIf IsSelected = False Then
            MsgBox("Choose Script(s)/Table Names from the list", MsgBoxStyle.Critical, Title:="Selection Required")
            Return False
        Else
            Return True
        End If

    End Function
    Public Function XML_Reader_Dropdown(ByVal XMLPath As String) As Integer

        Dim m_xmld As XmlDocument
        Dim m_nodelist As XmlNodeList
        Dim m_node As XmlNode
        Dim FldCnt As Integer
        m_xmld = New XmlDocument()
        m_xmld.Load(XMLPath)
        m_nodelist = m_xmld.SelectNodes("/Table/Field")
        For Each m_node In m_nodelist
            MnFrm.Cmbx_CustNm.Items.Add(m_node.ChildNodes.Item(0).InnerText)
            FldCnt = FldCnt + 1
        Next
        Return FldCnt

    End Function
    Private Function ConvertToLetter(ByVal num As Integer) As String
        'Method to convert an column number to column name
        If num < 0 Or num >= 27 * 26 Then
            ConvertToLetter = "-"
        Else
            If num < 26 Then
                ConvertToLetter = Chr(num + 65)
            Else
                ConvertToLetter = Chr(num \ 26 + 64) + Chr(num Mod 26 + 65)
            End If
        End If
    End Function
    Private Sub releaseObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
        Finally
            GC.Collect()
        End Try
    End Sub
    Public Sub Refresh_Grid()
        MnFrm.dgv_statusbar.Text = IIf(MnFrm.dgv_MsmtDta.RowCount = 0, 0, MnFrm.dgv_MsmtDta.RowCount - 1) & " row(s)"
    End Sub
    Public Function Retrive_Cust_FolderNames(ByVal FolderPath As String)
        MnFrm.Cmbx_CustNm.Items.Clear()
        MnFrm.cmbx_newCustNm.Items.Clear()
        For Each Dir As String In Directory.GetDirectories(FolderPath)
            Dim dirInfo As New DirectoryInfo(Dir)
            If dirInfo.Name <> "Archive" Then
                MnFrm.Cmbx_CustNm.Items.Add(dirInfo.Name)
                MnFrm.cmbx_newCustNm.Items.Add(dirInfo.Name)
            End If
        Next
        MnFrm.Cmbx_CustNm.Items.Add("Refresh")
        MnFrm.Cmbx_CustNm.Items.Add("Add New Customer")
    End Function

    Public Function CheckFolder(ByVal FolderPath As String)
        If (Not System.IO.Directory.Exists(FolderPath)) Then
            System.IO.Directory.CreateDirectory(FolderPath)
        End If
    End Function

End Module